g++ -c main.C -o ./exe.o
 g++ -o ./exe ./exe.o